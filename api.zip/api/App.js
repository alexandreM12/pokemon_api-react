import React, { useEffect, useState } from "react";
import {
  StyleSheet,  Text,  View, FlatList,  ActivityIndicator, Button, Image} from "react-native";
import axios from "axios";

export default function App() {
  const [pokemon, setPokemon] = useState(null);
  const [loading, setLoading] = useState(true);
  const [pokemonId, setPokemonId] = useState(1); 

  useEffect(() => {
    fetchPokemon(pokemonId); 
  }, [pokemonId]); 

  const fetchPokemon = async (id) => {
    setLoading(true); 
    try {
      const response = await axios.get(
        `https://pokeapi.co/api/v2/pokemon/${id}`
      );
      setPokemon(response.data); 
    } catch (error) {
      console.error("Erro ao buscar o Pokémon: ", error);
    } finally {
      setLoading(false); 
    }
  };

  const nextPokemon = () => {
    setPokemonId(pokemonId + 1); 
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#007BFF" />
      </View>
    );
  }

  const pokemonImageUrl = pokemon.sprites?.front_default;

  return (
    
    <View style={styles.container}>
    
      {pokemonImageUrl ? (
        <Image
          source={{ uri: pokemonImageUrl }} 
          style={styles.pokemonImage}
        />
      ) : (
        <Text>Imagem não disponível</Text> 
      )}
      
      <Text style={styles.title}>Nome: {pokemon.name}</Text>
      <Text style={styles.body}>ID: {pokemon.id}</Text>
      <Text style={styles.body}>Peso: {pokemon.weight}</Text>
      <Text style={styles.body}>Altura: {pokemon.height}</Text>
      <Text style={styles.title}>Habilidades:</Text>
      <FlatList
        data={pokemon.abilities} 
        keyExtractor={(item) => item.ability.name} 
        renderItem={({ item }) => (
          <Text style={styles.body}>{item.ability.name}</Text> 
        )}
      />
       <View style={styles.buttonContainer}>
        <Button
          title="Próximo"
          onPress={nextPokemon}
          color="#fff" 
        />
      </View>
    </View>
    
  );
}

const styles = StyleSheet.create({
  container: {
    display: 'flex',
    flex: 1,
    padding: 30,
    backgroundColor: '#F0F4F8',
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: '#333',
    marginBottom: 12,
    textAlign: 'center',
    fontFamily: 'Helvetica Neue',
  },
  body: {
    fontSize: 16,
    color: '#444',
    marginBottom: 10,
    textAlign: 'center',
    fontFamily: 'Arial',
  },
  pokemonImage: {
    marginTop: 30,
    width: 150,  
    height: 150, 
    marginBottom: 20, 
  },
  buttonContainer: {

    marginTop: 0, 
    width: '100%', 
    backgroundColor: '#007BFF', 
    borderRadius: 5, 
    overflow: 'hidden', 
    marginBottom: 200,
  },
});
